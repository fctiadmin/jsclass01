// var rana=500;
// document.write(rana);
// console.log(rana);
// window.alert(rana);
// var result=document.getElementById('result');
// result.innerHTML=rana;

// select section start
// document.getElementsByClassName('para')[0].innerHTML="My name is Zahid ";
// document.getElementsByTagName('p')[1].innerHTML="<b>Hi</b> ";
// document.getElementById('demo').innerText='Hello World';
// document.querySelector('#demo').innerHTML="Helow";
// var x,y,z,result;
// x=10;
// y=20;
// z=20;
// result=x+y+z;
// console.log(result);
// string how to write js
function btn(){
    var sname=document.getElementById('sname').value;
var sroll=document.getElementById('roll').value;
var course=document.getElementById('course').value;
var output="I am "+sname+"."+" My roll "+sroll+"."+" My course "+course+".";
 console.log(output);
}
// console.log(output.toLowerCase());
// console.log(output.toUpperCase());
// console.log(output);